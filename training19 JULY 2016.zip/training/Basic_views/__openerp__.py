
{
    'name': 'Basic views',
    'category': 'Test',
    'version': '1.0',
    'author': 'Developer',
    'depends': ['base'],

    'description': """
     Advanced views in odoo""",
    'data': [
        'views/basic_view.xml',
    ],
}
