{
'name': "delegation inherit",
'summary': "delegation exampl",
'description':""" D.Annadurai App Sodexis 2016 """,
'author': "Annadurai",
'website': "www.google.com ",
'category': 'uncategorized',
'version':'0.1',
'depends':['base'],
'data':[
        'views/view1.xml',
        'views/view2.xml',
        
        ],
        

}