
{
    'name': 'Advanced views',
    'category': 'Test',
    'version': '1.0',
    'author': 'Me',
    'depends': ['base'],

    'description': """
     Advanced views in odoo""",
    'data': [
        'views/advanced_view.xml',
    ],
}
