import advanced_view


