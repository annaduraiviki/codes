{
'name':'websiteTut',
'description':'Website making',
'version':'1.0',
'author':'Annadurai',
'data':['views/pages.xml','views/layout.xml',
        ],
'category':'Theme/Creative',
'depends':['website'],
'application': True

}