{
'name': "VMS custom",
'summary': "Trainees Vechiclemanufacturing system management system",
'description':""" D.Annadurai  Sodexis 2016 """,
'author': "Annadurai",
'website': "www.google.com ",
'category': 'uncategorized',
'version':'0.1',
'depends':['base','vechiclemanufacturer',],
'data':[#'views/production.xml',
        #'views/carparts.xml',
        #'views/service.xml',
        'views/customercustom.xml',
        'views/suppliercustom.xml',
        
        ],
        
  'qweb': [],      

}